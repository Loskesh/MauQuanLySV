﻿namespace BasicGroceryStore
{
    public class Imported : Bill
    {

    }
}
